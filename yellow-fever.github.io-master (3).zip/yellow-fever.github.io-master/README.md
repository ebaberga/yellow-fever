

<html>
<link rel="stylesheet" type="text/css" href="eba.css">
<body>
<h1>Yellow-Fever outbreaks in Africa and South America</h1>
<h2>Project Question:</h3>
<ol>
<li>How similar or Different is the yellow fever outbreaks in Africa and Brazil?</li>
<li>Which African countries have the same or almost the similar Yellow Fever virus outbreak</li>
 
</ol>
<h3>Countries I am Specifically interested in:</h2>
<ul>
  <li>Senegal</li>
  <li>Ethiopia</li>
  <li>Egypt</li>
  <li>Sudan</li>
  <li>Brazil</li>
  <li>Mali</li>
  <li>Nigeria</li>
</ul>
<h3>The following is my initial hypothesis:</h3>
<ul>
<li>Before drawing my tree, I thought locations played a significant role in the distribution of of yellow fever virus across Africa and Brazil.In other words, West African countries tends to have similar outbreak with Brazil than other East African countries. </li>
</ul>
<li>If you are wondering ....... why?</li>
<ul>
<li>Pangea can explain alot why West African countries should have similar outbreaks as Brazil than other East African counties, if the distribution of Yellow Fever Virus was related to enviromental factors</li>
</ul>
<p>click on the following link to learn more about Pangea<a href="https://en.wikipedia.org/wiki/Pangaea">&nbsp&nbsp&nbsp&nbspPANGEA</a></p>
<img src="yellowfever_fullgenome_AfrSA.png" >
</body>
</html>

